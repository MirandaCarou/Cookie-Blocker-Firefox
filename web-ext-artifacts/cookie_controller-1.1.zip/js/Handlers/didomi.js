

class Didomi extends Handler{
    constructor(){
        super();
        this.hostName = 'didomi';
        this.rootName = 'didomi-host';
        this.acceptAllId = 'didomi-notice-agree-button';
        this.configuration = 'didomi-notice-learn-more-button';
        this.savePreferences = 'didomi-components-button didomi-button didomi-button-standard standard-button';
    }


}
